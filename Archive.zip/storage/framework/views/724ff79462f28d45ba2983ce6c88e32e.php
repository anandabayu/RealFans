<?php $__env->startSection('pages'); ?>
    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->has('error')): ?>
        <div class="alert alert-danger mb-3">
            <?php echo e($errors->first('error')); ?>

        </div>
    <?php endif; ?>

    <?php if($user == null): ?>
        <div class="alert alert-danger mb-3">
            User not found!
        </div>
    <?php endif; ?>

    <?php if($user != null): ?>
        <?php echo $__env->make('pages.user.sections.payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('pages.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anandabayu/Workspace/PHP/The Digital Cellar/realfans/resources/views/pages/user/subscribe.blade.php ENDPATH**/ ?>