<div class="card mb-3">
    <form action="<?php echo e(route('post')); ?>"
          method="post"
          enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="card-header fw-bold">
            Post your content now!
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Choose Image</label>
                <div class="col-sm-9">
                    <input type="file"
                           class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           name="image"
                           id="selectImage"
                           accept="image/*">
                </div>
                <?php if($errors->has('image')): ?>
                    <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                <?php endif; ?>
                <img id="preview"
                     src="#"
                     class="mt-3 mx-auto"
                     alt="choose-avatar"
                     style="display:none; width: 100%; height: 150px; object-fit: cover;"/>
            </div>

            <div class="row p-2">
                <textarea
                    itemid="caption"
                    name="caption"
                    class="form-control <?php $__errorArgs = ['caption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="caption"
                    maxlength="255"
                    placeholder="Write your caption here"
                    rows="3"
                ><?php echo e(old('caption')); ?></textarea>
                <?php if($errors->has('caption')): ?>
                    <span class="text-danger"><?php echo e($errors->first('caption')); ?></span>
                <?php endif; ?>
            </div>

            <div class="row p-2">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="is_checked" name="is_checked">
                    <label class="form-check-label" for="is_checked">Locked (Subscriber only)</label>
                </div>
            </div>
        </div>
        <div class="card-footer text-end">
            <button type="submit" class="btn btn-success">Post</button>
        </div>
    </form>
</div>

<?php $__env->startPush('script'); ?>
    <script>
        selectImage.onchange = evt => {
            preview = document.getElementById('preview');
            preview.style.display = 'block';
            const [file] = selectImage.files
            if (file) {
                preview.src = URL.createObjectURL(file)
            }
        }
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /Users/anandabayu/Workspace/PHP/The Digital Cellar/realfans/resources/views/pages/home/sections/post.blade.php ENDPATH**/ ?>