<div class="card mb-3">
    <img src="<?php echo e(asset('storage/images/'.$user->avatar)); ?>"
         class="card-img-top rounded-circle mx-auto mt-2"
         alt="profile-image"
         style="width: 150px; height: 150px; object-fit: cover;"
    >
    <div class="card-body">
        <div class="row">
            <div class="col-md-7">
                <h5 class="card-title mt-3"><?php echo e($user->name); ?></h5>
            </div>
            <?php if(Auth::user()->id != $user->id): ?>
            <div class="col-md-5 text-end">
                <a href="<?php echo e(route(Auth::user()->isFollowing($user) ? "unfollow" : "follow", $user->username)); ?>"
                   class="btn btn-sm <?php echo e(Auth::user()->isFollowing($user) ? "btn-danger" : "btn-primary"); ?>">
                    <?php echo e(Auth::user()->isFollowing($user) ? "Unfollow" : "Follow"); ?>

                </a>

                <a href="<?php echo e(Auth::user()->isSubscribe($user) ? "#" : route("subscribe", $user->username)); ?>"
                   class="btn btn-sm <?php echo e(Auth::user()->isSubscribe($user) ? "btn-success" : "btn-primary"); ?>">
                    <?php echo e(Auth::user()->isSubscribe($user) ? "You already Subscribed" : "Subscribe"); ?>

                </a>
            </div>
            <?php endif; ?>
        </div>
        <p class="card-text">
            <?php echo e('@'.$user->username); ?>

            <span class="fst-italic" style="font-size: 11px;">
                <?php echo e($user->isFollowing(Auth::user()) ? " ~ Follows you" : ""); ?>

            </span>
        </p>
    </div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item">
            <div class="row text-center">
                <div class="col-md-6">
                    <span class="text-dark"><?php echo e($user->following()->count()); ?></span>
                    <span class="text-secondary">following</span>
                </div>
                <div class="col-md-6">
                    <span class="text-dark"><?php echo e($user->follower()->count()); ?></span>
                    <span class="text-secondary">followers</span>
                </div>
            </div>
        </li>
    </ul>
</div>
<?php /**PATH /Users/anandabayu/Workspace/PHP/The Digital Cellar/realfans/resources/views/pages/user/sections/info.blade.php ENDPATH**/ ?>