<?php $__env->startSection('pages'); ?>
    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->has('error')): ?>
        <div class="alert alert-danger mb-3">
            <?php echo e($errors->first('error')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-6">
            <?php echo $__env->make('pages.profile.sections.following', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-md-6">
            <?php echo $__env->make('pages.profile.sections.followers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('pages.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anandabayu/Workspace/PHP/The Digital Cellar/realfans/resources/views/pages/profile/follower.blade.php ENDPATH**/ ?>