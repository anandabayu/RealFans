<div class="card">
    <form action="<?php echo e(route('change-avatar')); ?>"
          method="post"
          enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="card-header fw-bold">
            Change Avatar
        </div>
        <div class="card-body">

            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Choose Avatar</label>
                <div class="col-sm-9">
                    <input type="file"
                           class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           name="image"
                           id="selectImage"
                           accept="image/*">
                </div>
                <?php if($errors->has('image')): ?>
                    <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                <?php endif; ?>
                <img id="preview"
                     src="#"
                     class="mt-3 mx-auto"
                     alt="choose-avatar"
                     style="display:none; width: 150px; height: 150px; object-fit: cover;"/>
            </div>
        </div>
        <div class="card-footer text-end">
            <button type="submit" class="btn btn-success">Save</button>
        </div>
    </form>
</div>

<?php $__env->startPush('script'); ?>
    <script>
        selectImage.onchange = evt => {
            preview = document.getElementById('preview');
            preview.style.display = 'block';
            const [file] = selectImage.files
            if (file) {
                preview.src = URL.createObjectURL(file)
            }
        }
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /Users/anandabayu/Workspace/PHP/The Digital Cellar/realfans/resources/views/pages/profile/sections/avatar.blade.php ENDPATH**/ ?>