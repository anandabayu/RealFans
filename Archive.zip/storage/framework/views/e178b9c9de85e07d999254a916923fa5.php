<div class="card">
    <img src="<?php echo e(asset('storage/images/avatar/'.Auth::user()->avatar)); ?>"
         class="card-img-top rounded-circle mx-auto mt-2"
         alt="profile-image"
         style="width: 150px; height: 150px; object-fit: cover;"
    >
    <div class="card-body">




        <h5 class="card-title mt-3"><?php echo e(Auth::user()->name); ?></h5>
        <p class="card-text"><?php echo e('@'.Auth::user()->username); ?></p>

    </div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item">
            <div class="row text-center">
                <div class="col-md-6">
                    <span class="text-dark">50</span>
                    <span class="text-secondary">following</span>
                </div>
                <div class="col-md-6">
                    <span class="text-dark">50</span>
                    <span class="text-secondary">followers</span>
                </div>
            </div>
        </li>
        <li class="list-group-item">
            <a href="<?php echo e(route('profile')); ?>" class="nav-link text-dark">Profile</a>
        </li>
    </ul>
</div>
<?php /**PATH /Users/anandabayu/Workspace/PHP/The Digital Cellar/realfans/resources/views/pages/sections/index.blade.php ENDPATH**/ ?>
