<div class="card">
    <a href="<?php echo e(route('user-info', Auth::user()->username )); ?>" class="mx-auto">
    <img src="<?php echo e(asset('storage/images/'.Auth::user()->avatar)); ?>"
         class="card-img-top rounded-circle mt-2"
         alt="profile-image"
         style="width: 150px; height: 150px; object-fit: cover;"
    >
    </a>
    <div class="card-body">
        <a href="<?php echo e(route('user-info', Auth::user()->username )); ?>" class="card-title mt-3 text-decoration-none">
            <h5><?php echo e(Auth::user()->name); ?></h5>
        </a>
        <a href="<?php echo e(route('user-info', Auth::user()->username )); ?>" class="card-text text-decoration-none">
            <p class="card-text"><?php echo e('@'.Auth::user()->username); ?></p>
        </a>
    </div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item">
            <a href="<?php echo e(route('followers')); ?>">
                <div class="row text-center">
                    <div class="col-md-6">
                        <span class="text-dark"><?php echo e(Auth::user()->following()->count()); ?></span>
                        <span class="text-secondary">following</span>
                    </div>
                    <div class="col-md-6">
                        <span class="text-dark"><?php echo e(Auth::user()->follower()->count()); ?></span>
                        <span class="text-secondary">followers</span>
                    </div>
                </div>
            </a>
        </li>
        <li class="list-group-item">
            <a href="<?php echo e(route('profile')); ?>" class="nav-link text-dark">Profile</a>
        </li>
        <li class="list-group-item">
            <a href="<?php echo e(route('logout')); ?>" class="nav-link text-dark" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();"
            >Log out</a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            </form>
        </li>
    </ul>
</div>
<?php /**PATH /Users/anandabayu/Workspace/PHP/The Digital Cellar/realfans/resources/views/pages/sections/info.blade.php ENDPATH**/ ?>