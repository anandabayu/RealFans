
<button class="col-md-12">INI BUTTON</button>
<?php /**PATH /Users/anandabayu/Workspace/PHP/The Digital Cellar/realfans/resources/views/pages/sections/content.blade.php ENDPATH**/ ?>
