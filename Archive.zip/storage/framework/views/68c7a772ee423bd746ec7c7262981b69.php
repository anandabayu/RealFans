<div class="card">
    <div class="card-header fw-bold">
        <?php echo e($following->count()); ?> Following
    </div>
    <div class="card-body">
        <?php $__currentLoopData = $following; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row mb-3">
                <div class="col-md-2">
                    <a href="<?php echo e(route('user-info', $follower->userWhoFollow->username )); ?>">
                        <img src="<?php echo e(asset('storage/images/'.$follower->userWhoFollow->avatar)); ?>"
                             class="card-img-top rounded-circle mx-auto"
                             alt="user-profile-image"
                             style="width: 50px; height: 50px; object-fit: cover;"
                        >
                    </a>
                </div>
                <div class="col-md-7">
                    <div>
                        <a href="<?php echo e(route('user-info', $follower->userWhoFollow->username )); ?>" class="text-dark fw-bold text-decoration-none">
                            <?php echo e($follower->userWhoFollow->name); ?>

                        </a>
                    </div>
                    <div>
                        <a href="<?php echo e(route('user-info', $follower->userWhoFollow->username )); ?>" class="text-secondary text-decoration-none">
                            <?php echo e('@'.$follower->userWhoFollow->username); ?>

                            <span class="fst-italic" style="font-size: 11px;">
                            <?php echo e($follower->userWhoFollow->isFollowing(Auth::user()) ? " ~ Follows you" : ""); ?>

                        </span>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route(Auth::user()->isFollowing($follower->userWhoFollow) ? "unfollow" : "follow", $follower->userWhoFollow->username)); ?>"
                       class="btn btn-sm <?php echo e(Auth::user()->isFollowing($follower->userWhoFollow) ? "btn-danger" : "btn-primary"); ?>">
                        <?php echo e(Auth::user()->isFollowing($follower->userWhoFollow) ? "Unfollow" : "Follow"); ?>

                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH /Users/anandabayu/Workspace/PHP/The Digital Cellar/realfans/resources/views/pages/profile/sections/following.blade.php ENDPATH**/ ?>