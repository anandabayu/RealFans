<?php $__env->startSection('content'); ?>
<div class="row mt-3">

    <div class="col-md-3">
        <?php echo $__env->make('pages/sections/info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="col-md-9">
        <?php echo $__env->yieldContent('pages'); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anandabayu/Workspace/PHP/The Digital Cellar/realfans/resources/views/pages/layout.blade.php ENDPATH**/ ?>